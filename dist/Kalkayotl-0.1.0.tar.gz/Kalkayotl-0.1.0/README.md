# kalkayotl
This repository contains a simple code to infer distances from parallaxes.

The documentation can be found at http://perso.astrophy.u-bordeaux.fr/JOlivares/kalkayotl/index.html
