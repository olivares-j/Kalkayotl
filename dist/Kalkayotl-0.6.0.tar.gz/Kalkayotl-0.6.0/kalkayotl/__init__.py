name = "Kalkayotl"
from kalkayotl.inference import Inference
